const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Use cors middleware
app.use(cors());
app.use(bodyParser.json());

let playlist = [];

// Get all songs
app.get('/playlist', (req, res) => {
  res.json(playlist);
});

// Get a specific song by ID
app.get('/playlist/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const song = playlist.find(item => item.id === id);

  if (song) {
    res.json(song);
  } else {
    res.status(404).json({ message: 'Song not found' });
  }
});

// Add a new song
app.post('/playlist', (req, res) => {
  const { title, artist } = req.body;
  const newSong = { id: playlist.length + 1, title, artist };
  playlist.push(newSong);
  res.status(201).json(newSong);
});

// Update a song
app.put('/playlist/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { title, artist } = req.body;
  const songIndex = playlist.findIndex(item => item.id === id);

  if (songIndex !== -1) {
    playlist[songIndex] = { id, title, artist };
    res.json(playlist[songIndex]);
  } else {
    res.status(404).json({ message: 'Song not found' });
  }
});

// Delete a song
app.delete('/playlist/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const songIndex = playlist.findIndex(item => item.id === id);

  if (songIndex !== -1) {
    const deletedSong = playlist.splice(songIndex, 1);
    res.json(deletedSong[0]);
  } else {
    res.status(404).json({ message: 'Song not found' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
